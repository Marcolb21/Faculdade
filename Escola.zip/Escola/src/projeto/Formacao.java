package projeto;
import java.util.Scanner;
public class Formacao {
	String titulo;
	String nomeC;
	int chC;
	
	Scanner ler = new Scanner(System.in);

	public Formacao() {
		super();
	}

	public Formacao(String titulo, String nomeC, int chC) {
		super();
		this.titulo = titulo;
		this.nomeC = nomeC;
		this.chC = chC;
	}

	public String getTitulo() {
		return titulo;
	}

	public void setTitulo(String titulo) {
		System.out.println("Qaul o tipo de forma��o? (Licenciatura, Tecnologo, Bacharelado)");
		titulo = ler.nextLine();
		this.titulo = titulo;
	}

	public String getNomeC() {
		return nomeC;
	}

	public void setNomeC(String nomeC) {
		System.out.println("Qual o nome do curso?");
		nomeC = ler.nextLine();
		this.nomeC = nomeC;
	}

	public int getChC() {
		return chC;
	}

	public void setChC(int chC) {
		System.out.println("Qual a carga horaria do curso?");
		chC = ler.nextInt();
		this.chC = chC;
	}
	
	public void cadastrarForma() {
		setTitulo(titulo);
		setNomeC(nomeC);
		setChC(chC);
	}
	
	public void showForma() {
		System.out.println("===Forma��o===");
		System.out.println("Titula��o: " +getTitulo()+ 
				"Nome do Curso: " +getNomeC() + 
				"Carga horaria do curso: " + getChC());
	}

}
