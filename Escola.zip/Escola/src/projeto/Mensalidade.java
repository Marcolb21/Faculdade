package projeto;

public interface Mensalidade {
	final double TEC = 600.90; // mensalidade do Ensino M�dio  
	final double BAC = 750.50; // mensalidade do Ensino Fundamental
	final double LIC = 850.80; // mensalidade do Curso integral (EM + T�cnico)
	
	//CARGA HORARIA
	
	final int chTec=2000;
	final int chBac=3000;
	final int chLic=4000;
		
	public abstract void CalculoMensalidade (int Curso);



}
