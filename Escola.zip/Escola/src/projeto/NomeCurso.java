package projeto;

public enum NomeCurso {
	ADS,C_COMPUTACAO, S_INFORMACAO;

}
