package projeto;

public enum Sexo {
MASCULINO, FEMININO;
}
