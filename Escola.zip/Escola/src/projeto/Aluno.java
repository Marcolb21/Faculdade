package projeto;

import java.util.Scanner;

public class Aluno extends Pessoa  {
	private byte ra;
	
	

	Curso c = new Curso();

	public Aluno() {
		super();
	}

	public Aluno(String cpf, String nome, Sexo sexo, Endere�o endereco, Curso cur) {
		super(cpf, nome, sexo, endereco);
		// TODO Auto-generated constructor stub
	}

	public byte getRa() {
		return ra;
	}

	public void setRa(byte ra) {
		System.out.print("Digite o Registro Acad�mico do aluno(a): ");
		ra = ler.nextByte();
		this.ra = ra;
	}

	public void cadastrarAluno(Scanner ler) throws Exception {

		System.out.println("\n-- Cadastramento --");

		setCpf(cpf);
		setNome(nome);
		setSexo(sexo);
		setRa(ra);
		end.cadastrarEnd();
		c.cadastrarCur();

	}
	
	
	

	public void dadosAluno() {
		System.out.println("===Dados===");
		System.out.println(" Nome: " +getNome() +
				"\n CPF: " + getCpf() + 
				"\n Sexo: " + getSexo()+ 
				"\n Registro Academico: " + getRa());
		end.showEnd();
		c.showCur();

	}

}
