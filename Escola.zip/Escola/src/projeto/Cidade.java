package projeto;

public enum Cidade {
	BeloHorizonte, NovaLima, Contagem, Betim, Sabara, Caete, Neves, SantaLuzia;

}
