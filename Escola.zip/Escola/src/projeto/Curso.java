package projeto;

import java.util.InputMismatchException;
import java.util.Scanner;

public class Curso implements Mensalidade {
	String nome;
	String tipo;
	int ch;
	float duracao;
	double mensalidade;
	int opcCurso = 0;
	int tipoC = 0;
	public NomeCurso nomeC;

	Scanner ler = new Scanner(System.in);

	public Curso() {
		super();
	}

	public Curso(String nome, String tipo, int ch, byte duracao, float mensalidade) {
		super();
		this.nome = nome;
		this.tipo = tipo;
		this.ch = ch;
		this.duracao = duracao;
		this.mensalidade = mensalidade;
	}

	public NomeCurso getNomeC() {
		return nomeC;
	}

	public void setNomeC(NomeCurso nomeC) {
		boolean saida = true;
		do {
			try {
				System.out.println(
						"Qual o nome do curso? 1 - ADS || 2 - Ciencia da Computa��o || 3 - Sistema da Informa��o ");
				tipoC = ler.nextInt();

				switch (tipoC) {
				case 1:
					nomeC = NomeCurso.ADS;
					saida = true;
					break;
				case 2:
					nomeC = NomeCurso.C_COMPUTACAO;
					saida = true;
					break;
				case 3:
					nomeC = NomeCurso.S_INFORMACAO;
					saida = true;
					break;
				default:
					System.out.println("Escolha uma op��o de 1 ao 3!!");
					saida = false;
					break;

				}

			} catch (InputMismatchException e) {

				System.out.println("Digite a op��o valida!");
				saida = false;
				ler.next();
			} finally {

				this.nomeC = nomeC;
			}
		} while (saida != true);
	}
	

	public double getMensalidade() {
		return mensalidade;
	}

	public void setMensalidade(double mensalidade) {
		this.mensalidade = mensalidade;
	}

	public String getNome() {
		return nome;

	}

	public void setNome(String nome) {
		System.out.println("Qual o nome do seu curso?");
		nome = ler.nextLine();
		this.nome = nome;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		System.out.println("Qual o tipo do curso? 1 - Tecnologo || 2 - Bacharelado || 3 - Licenciatura ");

		opcCurso = ler.nextInt();

		switch (opcCurso) {
		case 1:
			tipo = "Tecnologo";
			break;

		case 2:
			tipo = "Bacharelado";
			break;
		case 3:
			tipo = "Licenciatura";
			break;

		default:
			System.out.println("Op��o invalida");
			break;

		}

		this.tipo = tipo;

	}

	public void CalculoMensalidade(int opcCurso) {

		if (opcCurso == 1) {

			setMensalidade(TEC);
			setCh(chTec);

		}

		else if (opcCurso == 2) {

			mensalidade = BAC;
			setCh(chBac);
		} else if (opcCurso == 3) {

			mensalidade = LIC;
			setCh(chLic);
		} else {
			System.out.println("Op��o invalida");
		}

	}

	public float getDuracao() {
		return duracao;
	}

	public void setDuracao(float duracao) {
		System.out.println("Qual a dura��o do curso?");
		duracao = ler.nextFloat();
		this.duracao = duracao;
	}

	public void cadastrarCur() {
		setNome(nome);
		setNomeC(nomeC);
		setDuracao(duracao);
		setTipo(tipo);
		CalculoMensalidade(opcCurso);

	}

	public int getCh() {
		return ch;
	}

	public void setCh(int ch) {
		this.ch = ch;
	}

	public void showCur() {
		System.out.println("===Curso===");
		System.out.println(" Curso: " + getNome() + "\n Forma��o: " + getTipo() + "\n Mensalidade: " + getMensalidade()
				+ "\n Nome do Curso: " + getNomeC() + "\n Carga Horaria: " + getCh() + "\n Dura��o: " + getDuracao());
	}

}
