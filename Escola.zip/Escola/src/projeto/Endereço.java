package projeto;
import java.util.InputMismatchException;
import java.util.Scanner;

public class Endere�o {
	private String rua;
	private int numero;
	private String bairro;
	protected Cidade cidade;
	protected int opcCidade;
	private String uf;
	
	Scanner ler = new Scanner(System.in);
	public Endere�o() {
	}

	public Endere�o(String rua, int numero, String bairro, Cidade cidade, String uf) {
		super();
		this.rua = rua;
		this.numero = numero;
		this.bairro = bairro;
		this.cidade = cidade;
		this.uf = uf;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		System.out.println("Qual a sua rua?");
		rua = ler.nextLine();
		this.rua = rua;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
	System.out.println("Digite o n�mero da residencia:");
	numero = ler.nextInt();
		this.numero = numero;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		System.out.println("Qual o seu bairro? ");
		bairro = ler.nextLine();
		bairro = ler.nextLine();
		this.bairro = bairro;
	}

	
	public Cidade getCidade() {
		return cidade;
	}

	public void setCidade(Cidade cidade) throws Exception {
		
		boolean saida = true;
		do {
		
			try {
				System.out.println("Digite qual sua cidade: 1 - BH || 2 - Nova Lima || 3 - Contagem || 4 - Betim || 5 - Sabara || 6 - Caet� || 7 - Neves || 8 - Santa Luzia");
				
				
				opcCidade = ler.nextInt();
				switch(opcCidade) {
				
				case 1:
					cidade = Cidade.BeloHorizonte;
					saida = true;
					
					break;
				case 2:
					cidade = Cidade.NovaLima;
					saida = true;
					break;
				case 3:
					cidade = Cidade.Contagem;
					saida = true;
					break;
				case 4:
					cidade = Cidade.Betim;
					saida = true;
					break;
				case 5:
					cidade = Cidade.Sabara;
					saida = true;
					break;
				case 6:
					cidade = Cidade.Caete;
					saida = true;
					break;
				case 7:
					cidade = Cidade.Neves;
					saida = true;
					break;
				case 8:
					cidade = Cidade.SantaLuzia;
					saida = true;
					break;	
					
				default:
					System.out.println("Digite numeros de 1 ao 8! \n");
					saida = false;
				}
			
			
			}
			
			catch(InputMismatchException e) {
				
				System.out.println("Digite a op��o valida!");
				saida = false;
				ler.next();
			}
			finally {
				
				this.cidade = cidade;
			}
		}while (saida !=true);
		}
	
		
	


	

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		System.out.println("Qual o seu estado?");
		uf = ler.nextLine();
		this.uf = uf;
	}
	
	public void cadastrarEnd() throws Exception{
		setRua(rua);
		setNumero(numero);
		setBairro(bairro);
		setCidade(cidade);
		setUf(uf);
	}
	
	public void showEnd() {
		System.out.println("===Endere�o===");
		System.out.println(" Rua: " + getRua() +
				"\n Numero: " + getNumero() +
				"\n Bairro: " + getBairro() +
				"\n Cidade: " + getCidade() + 
				"\n Estado: " + getUf());
		
	}

	
}
