package projeto;
import java.util.Scanner;

public class Endere�o {
	private String rua;
	private int numero;
	private String bairro;
	private String cidade;
	private String uf;
	
	Scanner ler = new Scanner(System.in);
	public Endere�o() {
	}

	public Endere�o(String rua, int numero, String bairro, String cidade, String uf) {
		super();
		this.rua = rua;
		this.numero = numero;
		this.bairro = bairro;
		this.cidade = cidade;
		this.uf = uf;
	}

	public String getRua() {
		return rua;
	}

	public void setRua(String rua) {
		System.out.println("Qual a sua rua?");
		rua = ler.nextLine();
		this.rua = rua;
	}

	public int getNumero() {
		return numero;
	}

	public void setNumero(int numero) {
	System.out.println("Digite o n�mero da residencia:");
	numero = ler.nextInt();
		this.numero = numero;
	}

	public String getBairro() {
		return bairro;
	}

	public void setBairro(String bairro) {
		System.out.println("Qual o seu bairro? ");
		bairro = ler.nextLine();
		bairro = ler.nextLine();
		this.bairro = bairro;
	}

	public String getCidade() {
		return cidade;
	}

	public void setCidade(String cidade) {
		System.out.println("Qual sua cidade?");
		cidade = ler.nextLine();
		this.cidade = cidade;
	}

	public String getUf() {
		return uf;
	}

	public void setUf(String uf) {
		System.out.println("Qual o seu estado?");
		uf = ler.nextLine();
		this.uf = uf;
	}
	
	public void cadastrarEnd(){
		setRua(rua);
		setNumero(numero);
		setBairro(bairro);
		setCidade(cidade);
		setUf(uf);
	}
	
	public void showEnd() {
		System.out.println("===Endere�o===");
		System.out.println(" Rua: " + getRua() +
				"\n Numero: " + getNumero() +
				"\n Bairro: " + getBairro() +
				"\n Cidade: " + getCidade() + 
				"\n Estado: " + getUf());
		
	}

	
}
