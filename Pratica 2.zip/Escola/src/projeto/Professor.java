package projeto;

import java.util.Scanner;

public class Professor extends Pessoa implements Impostos {
	private int chP;
	private float salario;
	
	private double salarioIR;

	Formacao f = new Formacao();

	public Professor() {
		super();
	}
	public int getChP() {
		return chP;
	}

	public void setChP(int chP) {
		System.out.println("Qual a carga horaria trabalhada?");
		chP = ler.nextInt();
		this.chP = chP;
	}

	public float getSalario() {
		return salario;
	}

	public void setSalario(float salario) {
		System.out.println("Qual o seu salario?");
		salario = ler.nextFloat();
		this.salario = salario;
	}

	public void cadastrarProf(Scanner ler) {

		System.out.println("\n-- Cadastramento --");

		setCpf(cpf);
		setNome(nome);
		setSexo(sexo);
		f.cadastrarForma();
		setEndereco(endereco);
		setChP(chP);
		setSalario(salario);
		setSalarioIR(salario);

	}
	
	public void setSalarioIR(double salario) {
		if (salario <= 1903.98) {
			salario -= faixa1;
		} 
		else if (salario > 1903.98 && salario <= 2826.65) 
		{
			salario -= faixa2;
		}
		
		else if (salario > 2826.65 && salario <= 3751.05) {
			salario -= faixa3;
		}
		else if (salario > 3751.05 && salario <= 4664.68) {
			salario -= faixa4;
		}
		else {
			salario -= faixa5;
		}
		salarioIR = salario;
	}
	
	public double getSalarioIR() {
		return salarioIR;
	}

	public void dadosProf() {
		System.out.println("===Dados===");
		System.out.println(" Nome: " +getNome() +
				"\n CPF: " + getCpf() + 
				"\n Sexo: " + getSexo() +
				"\n Carga Horaria: "+ getChP() + 
				"\n Salario: " + getSalario() +
				"\n Salario com Desconto: " + getSalarioIR());
		
		end.showEnd();
		f.showForma();
		

	}
	
	@Override
	public double IR(double salario) { // porque � uma boa pr�tica � colocar o final aqui, no m�todo?
		// TODO Auto-generated method stub
		return 0;
	}

}
