package projeto;

import java.util.Scanner;

public abstract class Pessoa {
	protected String cpf;
	protected String nome;
	protected String sexo;
	protected Endere�o endereco;

	Scanner ler = new Scanner(System.in);
	Endere�o end = new Endere�o();

	public Pessoa() {

	}

	public Pessoa(String cpf, String nome, String sexo, Endere�o endereco) {
		super();
		this.cpf = cpf;
		this.nome = nome;
		this.sexo = sexo;
		this.endereco = endereco;
	}

	public String getCpf() {
		return cpf;
	}

	public void setCpf(String cpf) {
		System.out.print("Informe o CPF: ");
		cpf = ler.nextLine();

		while (cpf.length() != 11) {
			System.out.println("\nCPF invalido!!! \n");
			System.out.print("Informe o CPF: ");
			cpf = ler.nextLine();
		}
		this.cpf = cpf;

	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		System.out.print("Informe o nome: ");
		nome = ler.nextLine().toUpperCase();
		this.nome = nome;
	}

	public String getSexo() {
		return sexo;
	}

	public void setSexo(String sexo) {
		System.out.print("Informe o sexo: ");
		sexo = ler.nextLine();
		this.sexo = sexo;
	}
	
	public Endere�o getEndereco() {
		return endereco;
	}

	public void setEndereco(Endere�o endereco) {
		end.cadastrarEnd();
		endereco = end;
		
	}
}