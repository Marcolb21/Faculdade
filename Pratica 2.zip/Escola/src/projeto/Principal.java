package projeto;

import java.util.Scanner;

public class Principal {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner ler = new Scanner(System.in);

		Aluno a = new Aluno();
		Professor p = new Professor();

		byte opc;
		byte opc2;

		do {
			System.out.println("\n..: Menu Principal :..");
			System.out.println("----------------------");
			System.out.println("1 - Cadastrar pessoa");
			System.out.println("2 - Mostrar os dados");
			System.out.println("3 - Sair do sistema ");
			System.out.print("Digite uma op��o: ");
			opc = ler.nextByte();

			switch (opc) {
			case 1:
				System.out.println(" ");
				System.out.println("Voc� gostaria de:");
				System.out.println("----------------");
				System.out.println("1- Cadastrar Aluno");
				System.out.println("----------------");
				System.out.println("2- Cadastrar Professor");
				System.out.println();
				opc = ler.nextByte();
				if (opc == 1) {
					a.cadastrarAluno(ler);
				} else if (opc == 2) {
					p.cadastrarProf(ler);
				} else {
					System.out.println("Digite uma op��o valida");
					break;
				}
				break;
			case 2:
				System.out.println(" ");
				System.out.println("Voc� gostaria de:");
				System.out.println("----------------");
				System.out.println("1- Ver dados Aluno:");
				System.out.println("----------------");
				System.out.println("2- Ver dados Professor");
				opc2 = ler.nextByte();
				if (opc2 == 1) {
					System.out.println("\n Mostrando os dados digitados:");
					a.dadosAluno();
				} else if (opc2 == 2) {
					p.dadosProf();
				} else {
					System.out.println("Digite uma op��o valida");
				}
				break;
			case 3:
				System.out.println("Saindo do sistema...1...");
				break;
			default:
				System.out.println("Op��o Inv�lida!");
			}
		} while (opc != 3);

		ler.close();
	}

}