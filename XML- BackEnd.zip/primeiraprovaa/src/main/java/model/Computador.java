package model;

public class Computador {

    private String fabricante;
    private String processador;
    private String memoria;
    private String capacidadeHD;
    private String placaVideo;

    public Computador (String fabricante, String processador, String memoria, String capacidadeHD, String placaVideo){
        this.fabricante = fabricante;
        this.processador = processador;
        this.memoria = memoria;
        this.capacidadeHD = capacidadeHD;
        this.placaVideo = placaVideo;

    }

    public String getFabricante(){return fabricante;}
    public String getProcessador(){return processador;}

    public String getMemoria(){return memoria;}

    public String getCapacidadeHD(){return capacidadeHD;}

    public String getPlacaVideo(){return placaVideo;}


}
