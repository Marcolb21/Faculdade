package controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import model.Computador;
import service.ConvertXML;
import service.DataBind;

import java.io.IOException;

@WebServlet("/post")
public class PostController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        Computador computador = new DataBind().bind(req);

                resp.setHeader("Content-Type", "application/xml");
                resp.getWriter().println(new ConvertXML().toXML(computador));

        }
    }

