package service;

import jakarta.servlet.http.HttpServletRequest;
import model.Computador;

public class DataBind {

    public Computador bind(HttpServletRequest req) {

        Computador computador = new Computador(req.getParameter("fabricante"),
                req.getParameter("processador"),
                        req.getParameter("memoria"),
                                req.getParameter("capacidadeHD"),
                                        req.getParameter("placaVideo"));
        return computador;
    }
}
