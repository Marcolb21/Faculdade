package service;

import model.Computador;

public class ConvertXML {

    public String toXML(Computador computador) {
        StringBuilder xml = new StringBuilder();
        xml.append("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");
        xml.append("<computador>\n");
        xml.append("    <fabricante>" + computador.getFabricante() + "</fabricante>\n");
        xml.append("    <processador>" + computador.getProcessador() + "</processador>\n");
        xml.append("    <memoria>" + computador.getMemoria() + "</memoria>\n");
        xml.append("    <capacidadeHD>" + computador.getCapacidadeHD() + "</capacidadeHD>\n");
        xml.append("    <placaVideo>" + computador.getPlacaVideo() + "</placaVideo>\n");
        xml.append("</computador>\n");




        return xml.toString();
    }
}
